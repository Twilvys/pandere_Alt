import React from "react";
import Link from "next/link"; // <- Importamos el Link nativo de Next.js
interface TextoProps {
  // Definimos qué "variantes" permitiremos en nuestra app
  variant?: "h1" | "h2" | "p" | "subtitulo"| "link";
  children: React.ReactNode;
  className?: string; // Por si quieres añadir un estilo extra desde fuera
  href?: string; // Por si es un texto con enlace
}

export default function Texto({ variant = "p", children, className = "", href }: TextoProps) {
  
  // 1. Mapeamos cada variante con sus clases de Tailwind predefinidas
  const estilos = {
    h1: "text-4xl font-extrabold text-[#07191E] tracking-tight",
    h2: "text-2xl font-bold text-[#07191E] dark:text-zinc-100",
    subtitulo: "text-lg text-[#07191E] font-medium",
    p: "text-base text-[#07191E] leading-relaxed dark:text-zinc-400",
    link: "text-[#07191E] font-medium hover:text-blue-700 hover:underline underline-offset-4 transition-colors cursor-pointer"
  };

    if (variant === "link" && href) {
        return (
        <Link href={href} className={`${estilos.link} ${className}`}>
            {children}
        </Link>
    );
  }
  // 2. Elegimos dinámicamente qué etiqueta HTML real usar
  // Si la variante es 'subtitulo', semánticamente sigue siendo un párrafo (<p>)
  const Tag = variant === "subtitulo" ? "p" : variant;

  return (
    <Tag className={`${estilos[variant]} ${className}`}>
      {children}
    </Tag>
  );
}