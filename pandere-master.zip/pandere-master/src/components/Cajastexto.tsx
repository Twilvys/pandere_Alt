// src/components/InputTexto.tsx
import React from "react";

// 1. Definimos las propiedades exclusivas de nuestro componente
interface InputTextoProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string; // El título que verá el usuario arriba de la caja
}

export default function InputTexto({ label, id, type = "text", ...props }: InputTextoProps) {
  // 2. Fabricamos un ID automático basado en el texto del label para la accesibilidad
  const inputId = id || label.toLowerCase();

  return (
    <div className="flex flex-col gap-1.5 w-full max-w-md">
      
      {/* 3. La etiqueta de texto superior */}
      <label htmlFor={inputId} className="text-sm font-semibold text-[#F9FAFB] ">
        {label}
      </label>
      
      {/* 4. Diseño de la caja de texto */}
      <input
        id={inputId}
        type={type} /* Puede ser text, password, email, etc. */
        {...props}  /* Arrastra automáticamente placeholder, value, onChange, etc. */
        className="w-full px-4 py-2.5 text-base text-[#F9FAFB] bg-[#07191E] border border-zinc-300 
                   rounded-xl transition-all placeholder:text-zinc-400
                   focus:outline-none focus:border-[#02F5A1] focus:ring-4 focus:ring-[#02F5A1]"
      />
      
    </div>
  );
}