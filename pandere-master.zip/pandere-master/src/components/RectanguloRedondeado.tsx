// src/components/RectanguloRedondeado.tsx

// 1. Definimos las propiedades (props) que puede recibir el componente
// Esto nos permite reutilizarlo con diferentes colores y tamaños.
interface RectanguloProps {
  // El color de fondo (debe ser una clase válida de Tailwind, ej: 'bg-red-500')
  color?: string; 
  // Ancho y alto opcionales (ej: 'w-64 h-32')
  dimensiones?: string;
  // El texto que irá dentro
  children?: React.ReactNode; 
}

export default function RectanguloRedondeado({ 
  // 2. Definimos valores por defecto para cuando no se pasen props
  color = "bg-[#07191E]", 
  dimensiones = "w-auto h-auto", // Ancho mayor que alto para que sea rectángulo
  children
}: RectanguloProps) {
  
  return (
    // 3. Aplicamos las clases de Tailwind
    // 'rounded-3xl' es la clase que le da los bordes redondeados modernos.
    <div className={`${color} ${dimensiones} rounded-3xl shadow-xl flex items-center justify-center p-6`}>
      {/* 4. Renderizamos el contenido interno */}
      <div className="text-white font-semibold text-xl text-center">
        {children || "Rectángulo"}
      </div>
    </div>
  );
}