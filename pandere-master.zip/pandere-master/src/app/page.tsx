import Image from "next/image";
import RectanguloRedondeado from "@/components/RectanguloRedondeado";
import Cajastexto from "@/components/Cajastexto";
import Texto from "@/components/Texto";

export default function Login() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center bg-[#07191E] font-sans">
      <main className="space-y-4flex flex-1 w-full max-w-3xl flex-col items-center justify-between py-32 px-16 bg-[#02F5A1] sm:items-start">
        <Texto variant="h1">Inicio de sesion</Texto>
        <RectanguloRedondeado>
          <Cajastexto label="Correo Electronico"></Cajastexto>
          <br></br>
          <Cajastexto label="Contraseña" type="password"></Cajastexto>
          <br></br>
          <Texto variant="link"href="/registro"> Registrase</Texto>
        </RectanguloRedondeado>
        <Texto variant="link" href="/home">Ir a la página de inicio</Texto>
      </main>
    </div>
  );
}
